close all
clear
clc
load('195NF.mat')
plot(updatedelay, CDFNFJSPS,'-^b')
hold on
plot(updatedelay1, CDFFJSPS,'-or')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('NFJ-SPS','FJ-SPS','Location','southeast')