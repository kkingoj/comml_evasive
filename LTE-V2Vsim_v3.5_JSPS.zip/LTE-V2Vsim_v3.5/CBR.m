x=[42,84,126,168,195];
y=[0.256,0.398,0.550,0.676,0.734];
plot(x,y)
hold on
x1=42:1:195;
y1=0.6*x1/200;
plot(x1,y1)
hold on
x2=42:1:195;
y2=0.8*x2/200;
plot(x2,y2)
hold off
xlabel('Vehicle Density')
ylabel('CBR')
legend('Simulation','Analysis 300m','Analysis 400m','southeast')