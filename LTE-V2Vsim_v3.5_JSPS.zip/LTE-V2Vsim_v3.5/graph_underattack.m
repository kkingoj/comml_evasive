close all
clear
clc
load('UnAt42.mat')
plot(updatedelay, CDF42)
hold on
plot(updatedelay1, CDF84,'-o')
hold on
plot(updatedelay2, CDF126,'-^')
hold on
plot(updatedelay3, CDF168,'-+')
hold on
plot(updatedelay4, CDF195,'-*')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('42 vehicles/km','84 vehicles/km','126 vehicles/km','168 vehicles/km','195 vehicles/km','Location','southeast')
