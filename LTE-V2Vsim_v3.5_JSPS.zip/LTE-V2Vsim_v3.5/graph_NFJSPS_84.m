close all
clear
clc
load('84NF.mat')
plot(updatedelay, CDFNFJSPS,'-^b')
hold on
plot(updatedelay1, CDFFJ_SPS,'-or')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('NFJ-SPS','FJ-SPS','Location','southeast')