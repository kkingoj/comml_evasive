close all
clear
clc
load('At84.mat')
plot(updatedelay, CDFnoAttacker1,'-^b')
hold on
plot(updatedelay7, CDFSPSa1,'-xg')
hold on
plot(updatedelay8, CDFModeling1,'-or')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('Normal Situation','SPS-a with feedback','Modeling','Location','southeast')
