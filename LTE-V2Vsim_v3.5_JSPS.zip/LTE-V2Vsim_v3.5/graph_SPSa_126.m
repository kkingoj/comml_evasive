close all
clear
clc
load('At126.mat')
plot(updatedelay, CDFnoAttacker,'-^b')
hold on
plot(updatedelay6, CDFSPSa,'-xg')
hold on
plot(updatedelay7, CDFModeling,'-or')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('Normal Situation','SPS-a with feedback','Modeling','Location','southeast')
