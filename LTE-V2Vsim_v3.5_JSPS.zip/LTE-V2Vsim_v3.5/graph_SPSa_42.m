close all
clear
clc
load('At42.mat')
plot(updatedelay, CDFnoAttacker1,'-b')
hold on
plot(updatedelay6, CDFSPSa1,'-g')
hold on
plot(updatedelay7, CDFModeling1,'-r')
hold on
plot(updatedelay8, CDFtotal,'-m')
hold off
xlim([0 1])
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('Normal Situation','SPS-a with feedback','Modeling','Location','southeast')