function[BRCollAfterTx, BRCollBeforeTx, numTotFeed, numTrueFeed] = CollisionIndicator(BRCollAfterTx, BRCollBeforeTx,CBPThresh,IDvehicle,distance,BRid, ...
    Nbeacons,NbeaconsT,neighborsID, neighborsSINR,gammaMin, RxPower, numTotFeed, numTrueFeed, thrs)
% YJ Yoon: This function indicates collided Beacon Resource
Nvehicles = length(IDvehicle);
BRidT = mod(BRid-1,NbeaconsT)+1;
BRidF = ceil(BRid/NbeaconsT);
BRFmax = ceil(Nbeacons/NbeaconsT);

BRCollBeforeTx = BRCollAfterTx;
BRCollAfterTx = zeros(size(BRCollAfterTx));
% Sensing collision before transmit
for iV= 1:Nvehicles
    %if BRidT(IDvehicle(iV)) ~= 1
    % Attacker�� 1�� ������ collision �۾��� ���� �ʴ´�
    if IDvehicle(iV) == 1
        continue
    end
    
    for j=1:BRidT(IDvehicle(iV))-1
    %for j=BRidT(IDvehicle(iV))-1
        RxPsum=zeros(BRFmax,1);
        for subCHno = 1:BRFmax
            intindex=find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)==subCHno))==1);
            % Calculate Rx power sum 
            for k = 1:length(intindex)
                if IDvehicle(iV) ~= IDvehicle(intindex(k))
                    RxPsum(subCHno) = RxPsum(subCHno)+RxPower(iV,intindex(k));
                end
            end
        end
        for subCHno = 1:BRFmax
            intindex=find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)==subCHno))==1);
            % ���� powerSum�� threshold�� ������ decoding ������ beacon���� Ȯ��
            if RxPsum(subCHno) > CBPThresh
                [betweenDistance]=distance(IDvehicle(iV),IDvehicle(intindex));
                [minDistance, minIndex] = min(betweenDistance);
                idx= find(neighborsID(IDvehicle(iV),:) == IDvehicle(intindex(minIndex)));                
%                 tmp=find(BRid == j+(subCHno-1)*NbeaconsT);
%                 tmp1= intersect(tmp,neighborsID(IDvehicle(iV),:));
                temp1 = find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)~=subCHno))==1);
                %temp = intersect(temp1,neighborsID(IDvehicle(iV),:));
                if ~isempty(temp1)
                    [betD1] = distance(IDvehicle(iV),temp1);
                    [~,min1] = min(betD1);
                    min2=find(temp1(min1) == neighborsID(IDvehicle(iV),:));
                    if isempty(min2)
                        min2=length(IDvehicle)-1;
                    end
                end
                if isempty(temp1)
                    min2=length(IDvehicle)-1;
                end
                if ~isempty(idx) && neighborsSINR(IDvehicle(iV),idx)<gammaMin %&& minDistance<=100
                    numTotFeed = numTotFeed + 1;
                    %%if (subCHno-1>0 && RxPsum(subCHno-1)<=thrs)||(subCHno+1<BRFmax && RxPsum(subCHno+1)<=thrs)
                    %if isempty(temp)
                        BRCollBeforeTx(IDvehicle(iV),j+(subCHno-1)*NbeaconsT) = 1;
                        numTrueFeed=numTrueFeed+1;
                    %%else
%                         if isempty(min2)
%                             1;
%                         end
% %                         if gammaMin>neighborsSINR(IDvehicle(iV),min2)
% %                             BRCollBeforeTx(IDvehicle(iV),j+(subCHno-1)*NbeaconsT) = 1;
% %                             numTrueFeed=numTrueFeed+1;
% %                         end
% %                     end
%                     temp1 = find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)~=subCHno))==1);
%                     temp = intersect(temp1,neighborsID(IDvehicle(iV),:));
%                     [betD1] = distance(IDvehicle(iV),temp);
%                     [~,min1] = min(betD1);
%                     neighborsID(IDvehicle(iV),idx);
%                     neighborsSINR(IDvehicle(iV),IDvehicle(idx));
%                     temp(min1);
%                     min2=find(temp(min1) == neighborsID(IDvehicle(iV),:));
%                     neighborsSINR(IDvehicle(iV),min2);
%                     if neighborsSINR(IDvehicle(iV),min2) < 1000
%                         neighborsSINR(IDvehicle(iV),IDvehicle(idx))
%                         neighborsSINR(IDvehicle(iV),min2)
%                     end
%                           1;
                    
                end
            end
        end
    end
    %end
end

% Sensing Collision After Transmit
for iV= 1:Nvehicles
    % Attacker�� 1�� ������ collision �۾��� ���� �ʴ´�
    if IDvehicle(iV) == 1
        continue
    end
    
    %if BRidT(IDvehicle(iV)) == 1
    
    %for j = 100
    for j=BRidT(IDvehicle(iV))+1:NbeaconsT
        RxPsum=zeros(BRFmax,1);
        for subCHno = 1:BRFmax
            intindex=find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)==subCHno))==1);
            % Calculate Rx power sum 
            for k = 1:length(intindex)
                if IDvehicle(iV) ~= IDvehicle(intindex(k))
                    RxPsum(subCHno) = RxPsum(subCHno)+RxPower(iV,intindex(k));
                end
            end
        end
        for subCHno = 1:BRFmax
            intindex=find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)==subCHno))==1);
            % ���� powerSum�� threshold�� ������ decoding ������ beacon���� Ȯ��
            if RxPsum(subCHno) > CBPThresh
                [betweenDistance]=distance(IDvehicle(iV),IDvehicle(intindex));
                [minDistance, minIndex] = min(betweenDistance);
                idx= find(neighborsID(IDvehicle(iV),:) == IDvehicle(intindex(minIndex)));
%                 tmp=find(BRid == j+(subCHno-1)*NbeaconsT);
%                 tmp1= intersect(tmp,neighborsID(IDvehicle(iV),:));
                temp1 = find(((BRidT(IDvehicle)==j) & (BRidF(IDvehicle)~=subCHno))==1);
                %temp = intersect(temp1,neighborsID(IDvehicle(iV),:));
                if ~isempty(temp1)
                    [betD1] = distance(IDvehicle(iV),temp1);
                    [~,min1] = min(betD1);
                    min2=find(temp1(min1) == neighborsID(IDvehicle(iV),:));
                    if isempty(min2)
                        min2=length(IDvehicle)-1;
                    end
                end
                if isempty(temp1)
                    min2=length(IDvehicle)-1;
                end
                if ~isempty(idx) && neighborsSINR(IDvehicle(iV),idx)<gammaMin %&& minDistance<=100              
                    numTotFeed=numTotFeed+1;
                    %%if (subCHno-1>0 && RxPsum(subCHno-1)<=thrs)||(subCHno+1<BRFmax && RxPsum(subCHno+1)<=thrs)
                    %if isempty(temp)
                        BRCollAfterTx(IDvehicle(iV),j+(subCHno-1)*NbeaconsT) = 1;
                        numTrueFeed=numTrueFeed+1;
% %                     else
% %                         if gammaMin>neighborsSINR(IDvehicle(iV),min2)
% %                             BRCollAfterTx(IDvehicle(iV),j+(subCHno-1)*NbeaconsT) = 1;
% %                             numTrueFeed=numTrueFeed+1;
% %                         end
% %                     end
                end
            end
        end
    end
    %end
end
               
end
        