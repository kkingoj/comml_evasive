close all
clear
clc
load('At195.mat')
plot(updatedelay, CDFnoAttacker,'-^b')
hold on
plot(updatedelay5, CDFSPSa,'-xg')
hold on
plot(updatedelay7, CDFModeling,'-or')
hold off
xlabel('Update Delay (s)')
ylabel('CDF')
grid on
legend('Normal Situation','SPS-a with feedback','Modeling','Location','southeast')
