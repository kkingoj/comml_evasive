close all
clear
clc


% Simulation Environment Setting
density = [42,84,126,168];
for i = 1:length(density)
LTEV2Vsim('BenchmarkPoisson.cfg','simulationTime', 40,'BRAlgorithm',8,'printLOG', false,'lowITT', false, 'printDistanceDetails', false, ...
    'Raw',100,'rangeForVehicleDensity', 200, 'MCS', 7, 'rho',density(i),'smoothingFactorForITT', 1.0, ...                   % 100
    'beaconSizeBytes',300, 'powerControl', false, 'rateControl', false, 'Mborder', 0, 'probResKeep', 0.8, ...
    'roadLength', 3000, 'maxPtx_dBm',23, 'minPtx_dBm',10); 
end

